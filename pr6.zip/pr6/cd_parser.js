// Function to load XML file using fetch
function loadCDCatalogXML() {
    return fetch('cd_catalog.xml')  
        .then(response => response.text())  // Convert response to text
        .then(str => {
            const parser = new DOMParser(); // used to convert text into xml object
            return parser.parseFromString(str, "application/xml"); // Parse text as XML
        });
}

// Function to get the second CD's info
function getSecondCD() {
    loadCDCatalogXML().then(xmlDoc => {
        const cds = xmlDoc.getElementsByTagName("cd"); // Get all <cd> elements
        if (cds.length >= 2) {
            const secondCD = cds[1]; // Select the second CD

            // Extract all child info
            const title = secondCD.getElementsByTagName("title")[0].textContent;
            const artist = secondCD.getElementsByTagName("artist")[0].textContent;
            const country = secondCD.getElementsByTagName("country")[0].textContent;
            const company = secondCD.getElementsByTagName("company")[0].textContent;
            const price = secondCD.getElementsByTagName("price")[0].textContent;
            const year = secondCD.getElementsByTagName("year")[0].textContent;

            // Display in HTML
            document.getElementById("second-cd-info").innerHTML = `
                <p><strong>Title:</strong> ${title}</p>
                <p><strong>Artist:</strong> ${artist}</p>
                <p><strong>Country:</strong> ${country}</p>
                <p><strong>Company:</strong> ${company}</p>
                <p><strong>Price:</strong> ${price}</p>
                <p><strong>Year:</strong> ${year}</p>
            `;
        } else {
            alert("There are less than 2 CDs in the catalog.");
        }
    }).catch(err => {
        console.error("Error loading XML file:", err);
    });
}

// Call the function to display the second CD
getSecondCD();
